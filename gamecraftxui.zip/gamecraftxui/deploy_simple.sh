#!/bin/bash
# Простая загрузка проекта на хост (с вводом пароля)

HOST="u3320026@server67.hosting.reg.ru"
REMOTE_PATH="/var/www/u3320026/data/www/main0.ru"

echo "🚀 Начинаю загрузку проекта на хост..."
echo "📝 Пароль SSH: 5W9EtP7xBHc4WGkv"
echo ""

echo "📤 Загружаю server.js..."
scp server.js "$HOST:$REMOTE_PATH/"

echo "📤 Загружаю package.json..."
scp package.json "$HOST:$REMOTE_PATH/"

echo "📤 Загружаю package-lock.json..."
scp package-lock.json "$HOST:$REMOTE_PATH/"

echo "📤 Загружаю папку public (это может занять время)..."
scp -r public "$HOST:$REMOTE_PATH/"

echo ""
echo "✅ Файлы загружены!"
echo ""
echo "📤 Настраиваю сервер на хосте..."
echo "📝 Пароль SSH: 5W9EtP7xBHc4WGkv"
echo ""

# Останавливаем старый сервер
ssh "$HOST" "cd $REMOTE_PATH && pkill -f 'node server.js' || true"

# Устанавливаем зависимости
ssh "$HOST" "cd $REMOTE_PATH && npm install --production"

# Запускаем новый сервер
ssh "$HOST" "cd $REMOTE_PATH && PORT=8000 nohup node server.js > server.log 2>&1 &"

echo ""
echo "✅ Проект успешно загружен и запущен!"
echo "🌐 Сайт: https://main0.ru"
echo "📊 Проверить логи: ssh $HOST 'tail -f $REMOTE_PATH/server.log'"

