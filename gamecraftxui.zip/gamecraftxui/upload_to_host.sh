#!/bin/bash
# Скрипт для загрузки проекта на хост reg.ru

HOST="u3320026@server67.hosting.reg.ru"
REMOTE_PATH="/var/www/u3320026/data/www/main0.ru"

echo "🚀 Начинаю загрузку проекта на хост..."
echo ""

# 1. Загружаем основные файлы
echo "📤 Загружаю server.js..."
scp server.js $HOST:$REMOTE_PATH/

echo "📤 Загружаю package.json..."
scp package.json $HOST:$REMOTE_PATH/

echo "📤 Загружаю package-lock.json..."
scp package-lock.json $HOST:$REMOTE_PATH/

# 2. Загружаем папку public
echo "📤 Загружаю папку public..."
scp -r public $HOST:$REMOTE_PATH/

echo ""
echo "✅ Загрузка завершена!"
echo ""
echo "📝 Следующие шаги:"
echo "1. Подключитесь по SSH: ssh $HOST"
echo "2. Перейдите в папку: cd $REMOTE_PATH"
echo "3. Установите зависимости: npm install"
echo "4. Остановите старый сервер: pkill -f 'node server.js'"
echo "5. Запустите новый сервер: PORT=8000 nohup node server.js > server.log 2>&1 &"
