#!/bin/bash
# Автоматическая загрузка проекта на хост reg.ru

HOST="u3320026@server67.hosting.reg.ru"
REMOTE_PATH="/var/www/u3320026/data/www/main0.ru"
SSH_PASS="5W9EtP7xBHc4WGkv"

echo "🚀 Начинаю загрузку проекта на хост..."
echo ""

# Проверяем наличие sshpass
if ! command -v sshpass &> /dev/null; then
    echo "⚠️  sshpass не установлен. Устанавливаю..."
    if [[ "$OSTYPE" == "darwin"* ]]; then
        if command -v brew &> /dev/null; then
            brew install hudochenkov/sshpass/sshpass
        else
            echo "❌ Нужно установить sshpass вручную: brew install hudochenkov/sshpass/sshpass"
            exit 1
        fi
    fi
fi

# Функция для выполнения SSH команд
ssh_cmd() {
    sshpass -p "$SSH_PASS" ssh -o StrictHostKeyChecking=no "$HOST" "$1"
}

# Функция для SCP
scp_cmd() {
    sshpass -p "$SSH_PASS" scp -o StrictHostKeyChecking=no "$@"
}

echo "📤 Шаг 1/5: Загружаю server.js..."
scp_cmd server.js "$HOST:$REMOTE_PATH/"

echo "📤 Шаг 2/5: Загружаю package.json..."
scp_cmd package.json "$HOST:$REMOTE_PATH/"

echo "📤 Шаг 3/5: Загружаю package-lock.json..."
scp_cmd package-lock.json "$HOST:$REMOTE_PATH/"

echo "📤 Шаг 4/5: Загружаю папку public..."
scp_cmd -r public "$HOST:$REMOTE_PATH/"

echo "📤 Шаг 5/5: Настраиваю сервер на хосте..."
ssh_cmd "cd $REMOTE_PATH && pkill -f 'node server.js' || true"
ssh_cmd "cd $REMOTE_PATH && npm install --production"
ssh_cmd "cd $REMOTE_PATH && PORT=8000 nohup node server.js > server.log 2>&1 &"

echo ""
echo "✅ Проект успешно загружен и запущен на хосте!"
echo "🌐 Сайт доступен по адресу: https://main0.ru"
echo "📊 Логи сервера: ssh $HOST 'tail -f $REMOTE_PATH/server.log'"

