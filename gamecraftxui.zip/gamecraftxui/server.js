const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');
const { Pool } = require('pg');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const app = express();
const server = http.createServer(app);
// WebSocket сервер будет настроен после определения роутов
let wss;

// Инициализация PostgreSQL БД (одна БД на весь сайт)
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'gamecraft',
  user: process.env.DB_USER || process.env.USER || 'postgres',
  password: process.env.DB_PASSWORD || '',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Проверка подключения к БД
pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
  process.exit(-1);
});

// Инициализация таблиц
async function initDB() {
  try {
    // Таблица заявок
    await pool.query(`
      CREATE TABLE IF NOT EXISTS applications (
        id SERIAL PRIMARY KEY,
        fio VARCHAR(200) NOT NULL,
        group_name VARCHAR(50) NOT NULL,
        age INTEGER NOT NULL,
        college VARCHAR(200) NOT NULL,
        position VARCHAR(50) NOT NULL,
        date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `);
    await pool.query("CREATE INDEX IF NOT EXISTS idx_applications_date ON applications(date DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_applications_position ON applications(position)");

    // Таблица сообщений
    await pool.query(`
      CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        text TEXT NOT NULL,
        type VARCHAR(20) NOT NULL,
        date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        user_id VARCHAR(100)
      )
    `);
    await pool.query("CREATE INDEX IF NOT EXISTS idx_messages_date ON messages(date ASC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_messages_type ON messages(type)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id)");

    // Таблица отзывов
    await pool.query(`
      CREATE TABLE IF NOT EXISTS reviews (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        stars INTEGER NOT NULL,
        text TEXT NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `);
    await pool.query("CREATE INDEX IF NOT EXISTS idx_reviews_status ON reviews(status)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_reviews_date ON reviews(date DESC)");
    
    console.log('Database initialized successfully');
  } catch (err) {
    console.error('Database initialization error:', err);
    throw err;
  }
}

// Инициализация БД при запуске
initDB().catch(err => {
  console.error('Failed to initialize database:', err);
  console.warn('Server will continue without database. Some features may not work.');
  // Не останавливаем сервер, если БД недоступна
});

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(cors());

// Security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  next();
});

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100,
  message: 'Too many requests'
});

const applicationLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 5,
  message: 'Too many applications'
});

const chatLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  message: 'Too many messages'
});

const reviewLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 3,
  message: 'Too many reviews'
});

// Утилиты
function sanitizeString(s, maxLen) {
  if (!s) return '';
  s = s.trim();
  if (s.length > maxLen) s = s.substring(0, maxLen);
  s = s.replace(/<script/gi, '');
  s = s.replace(/<\/script>/gi, '');
  s = s.replace(/javascript:/gi, '');
  s = s.replace(/onerror=/gi, '');
  s = s.replace(/onclick=/gi, '');
  return s;
}

function validateApplication(app) {
  if (!app.fio || app.fio.length === 0 || app.fio.length > 200) {
    throw new Error('Invalid FIO');
  }
  if (!app.group || app.group.length === 0 || app.group.length > 50) {
    throw new Error('Invalid group');
  }
  if (!app.age || app.age < 14 || app.age > 99) {
    throw new Error('Invalid age');
  }
  if (!app.college || app.college.length === 0 || app.college.length > 200) {
    throw new Error('Invalid college');
  }
  if (!app.position || app.position.length === 0 || app.position.length > 50) {
    throw new Error('Invalid position');
  }
}

// WebSocket клиенты
const clients = new Map(); // Map<WebSocket, userID>

function broadcast(update) {
  clients.forEach((userID, ws) => {
    if (ws.readyState === WebSocket.OPEN) {
      if (update.message) {
        if (userID === 'admin') {
          ws.send(JSON.stringify(update));
        } else {
          if (update.message.user_id === userID || 
              update.message.type === 'bot' || 
              (update.message.type === 'admin' && update.message.user_id === userID)) {
            ws.send(JSON.stringify(update));
          }
        }
      } else {
        ws.send(JSON.stringify(update));
      }
    }
  });
}

// Инициализация WebSocket сервера
function initWebSocket() {
  wss = new WebSocket.Server({ noServer: true });
  
  // WebSocket обработка
  wss.on('connection', async (ws, req) => {
    if (clients.size >= 200) {
      ws.close(1008, 'Too many connections');
      return;
    }

    let userID = null;
    clients.set(ws, userID);

    // Ожидаем установки user_id
    const timeout = setTimeout(() => {
      if (!userID) {
        clients.delete(ws);
        ws.close();
      }
    }, 10000);

    ws.on('message', async (data) => {
      try {
        const msg = JSON.parse(data);
        
        if (msg.type === 'set_user_id' && msg.user_id) {
          userID = msg.user_id;
          clients.set(ws, userID);
          clearTimeout(timeout);

          // Отправляем историю
          let history;
          if (userID === 'admin') {
            const result = await pool.query('SELECT id, text, type, date, user_id FROM messages ORDER BY date DESC LIMIT 500');
            history = result.rows.reverse();
          } else {
            const result = await pool.query('SELECT id, text, type, date, user_id FROM messages WHERE user_id = $1 OR type = \'admin\' OR type = \'bot\' ORDER BY date DESC LIMIT 100', [userID]);
            history = result.rows.reverse();
          }
          
          history.forEach(msg => {
            ws.send(JSON.stringify({ type: 'history', message: msg }));
          });
          return;
        }

        if (msg.type === 'set_user_id') return;

        // Обработка сообщения
        if (!msg.text || msg.text.length === 0 || msg.text.length > 1000) {
          return;
        }

        const message = {
          text: sanitizeString(msg.text, 1000),
          type: ['user', 'admin', 'bot'].includes(msg.type) ? msg.type : 'user',
          date: new Date().toISOString(),
          user_id: msg.user_id || userID
        };

        const result = await pool.query('INSERT INTO messages (text, type, date, user_id) VALUES ($1, $2, $3, $4) RETURNING id', 
          [message.text, message.type, message.date, message.user_id]);
        message.id = result.rows[0].id;

        broadcast({ type: 'new_message', message });
      } catch (err) {
        console.error('WebSocket message error:', err);
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
    });

    ws.on('error', (err) => {
      console.error('WebSocket error:', err);
      clients.delete(ws);
    });
  });
  
  return wss;
}

// API Routes
const apiRouter = express.Router();

// Заявки
apiRouter.get('/applications', async (req, res) => {
  try {
    const result = await pool.query('SELECT id, fio, group_name as "group", age, college, position, date FROM applications ORDER BY date DESC LIMIT 1000');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.json(result.rows || []);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

apiRouter.post('/applications', applicationLimiter, async (req, res) => {
  try {
    const app = {
      fio: sanitizeString(req.body.fio, 200),
      group: sanitizeString(req.body.group, 50),
      age: req.body.age,
      college: sanitizeString(req.body.college, 200),
      position: sanitizeString(req.body.position, 50),
      date: new Date().toISOString()
    };

    validateApplication(app);

    const result = await pool.query('INSERT INTO applications (fio, group_name, age, college, position, date) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id',
      [app.fio, app.group, app.age, app.college, app.position, app.date]);
    app.id = result.rows[0].id;

    broadcast({ type: 'new_application' });
    res.status(201).json({ status: 'success' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

apiRouter.delete('/applications', async (req, res) => {
  try {
    await pool.query('DELETE FROM applications');
    res.json({ status: 'success' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Чат
apiRouter.get('/chat', async (req, res) => {
  try {
    const userID = req.query.user_id;
    let result;
    
    if (userID) {
      result = await pool.query('SELECT id, text, type, date, user_id FROM messages WHERE user_id = $1 OR type = \'admin\' OR type = \'bot\' ORDER BY date DESC LIMIT 500', [userID]);
    } else {
      result = await pool.query('SELECT id, text, type, date, user_id FROM messages ORDER BY date DESC LIMIT 500');
    }
    
    const messages = result.rows.reverse();
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.json(messages || []);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

apiRouter.post('/chat', chatLimiter, async (req, res) => {
  try {
    const msg = {
      text: sanitizeString(req.body.text, 1000),
      type: ['user', 'admin', 'bot'].includes(req.body.type) ? req.body.type : 'user',
      date: new Date().toISOString(),
      user_id: sanitizeString(req.body.user_id, 100)
    };

    if (!msg.text || msg.text.length === 0 || msg.text.length > 1000) {
      return res.status(400).json({ error: 'Invalid message' });
    }

    const result = await pool.query('INSERT INTO messages (text, type, date, user_id) VALUES ($1, $2, $3, $4) RETURNING id',
      [msg.text, msg.type, msg.date, msg.user_id]);
    msg.id = result.rows[0].id;

    broadcast({ type: 'new_message', message: msg });
    res.status(201).json(msg);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

apiRouter.delete('/chat', async (req, res) => {
  try {
    await pool.query('DELETE FROM messages');
    res.json({ status: 'success' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Отзывы
apiRouter.get('/reviews', async (req, res) => {
  try {
    const status = req.query.status;
    let result;
    
    if (status === 'approved') {
      result = await pool.query('SELECT id, name, stars, text, status, date FROM reviews WHERE status = $1 ORDER BY date DESC', ['approved']);
    } else if (status === 'pending') {
      result = await pool.query('SELECT id, name, stars, text, status, date FROM reviews WHERE status = $1 ORDER BY date DESC', ['pending']);
    } else {
      result = await pool.query('SELECT id, name, stars, text, status, date FROM reviews ORDER BY date DESC');
    }
    
    res.json(result.rows || []);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

apiRouter.post('/reviews', reviewLimiter, async (req, res) => {
  try {
    const review = {
      name: sanitizeString(req.body.name, 100),
      stars: req.body.stars,
      text: sanitizeString(req.body.text, 2000),
      status: ['pending', 'approved', 'rejected'].includes(req.body.status) ? req.body.status : 'pending',
      date: new Date().toISOString()
    };

    if (!review.name || review.name.length === 0 || review.name.length > 100) {
      return res.status(400).json({ error: 'Invalid name' });
    }
    if (!review.text || review.text.length === 0 || review.text.length > 2000) {
      return res.status(400).json({ error: 'Invalid text' });
    }
    if (!review.stars || review.stars < 1 || review.stars > 5) {
      return res.status(400).json({ error: 'Invalid stars' });
    }

    const result = await pool.query('INSERT INTO reviews (name, stars, text, status, date) VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [review.name, review.stars, review.text, review.status, review.date]);
    review.id = result.rows[0].id;

    broadcast({ type: 'new_review', review });
    res.status(201).json(review);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

apiRouter.put('/reviews/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const status = req.body.status;
    
    if (!['pending', 'approved', 'rejected'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    await pool.query('UPDATE reviews SET status = $1 WHERE id = $2', [status, id]);

    broadcast({ type: 'review_updated' });
    res.json({ status: 'success' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

apiRouter.delete('/reviews/:id', async (req, res) => {
  try {
    const id = req.params.id;
    await pool.query('DELETE FROM reviews WHERE id = $1', [id]);

    broadcast({ type: 'review_deleted' });
    res.json({ status: 'success' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Middleware для декодирования URL с кириллицей (только для статических файлов)
function decodeUrlMiddleware(req, res, next) {
  try {
    // Декодируем URL для правильной обработки кириллицы
    // Проверяем, нужно ли декодирование (если URL содержит %)
    if (req.url && req.url.includes('%')) {
      const decodedUrl = decodeURIComponent(req.url);
      req.url = decodedUrl;
      // Также обновляем path для express.static
      if (req.path) {
        req.path = decodeURIComponent(req.path);
      }
    }
  } catch (e) {
    // Если декодирование не удалось, оставляем как есть
  }
  next();
}

// Инициализация WebSocket
initWebSocket();

// API роуты ДО статических файлов
app.use('/api', apiLimiter, apiRouter);

// WebSocket upgrade обработка
server.on('upgrade', (request, socket, head) => {
  if (request.url === '/api/chat/ws') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

// Статические файлы с поддержкой кириллицы
// Serve main directory files at /main/... path
const mainStaticPath = path.join(__dirname, 'public', 'main');
console.log('Serving static files from:', mainStaticPath);
console.log('Main static path exists:', fs.existsSync(mainStaticPath));
if (fs.existsSync(mainStaticPath)) {
  const files = fs.readdirSync(mainStaticPath);
  console.log('Files in main directory:', files);
}

// Helper function to serve static files from /main directory
function serveMainFile(req, res) {
  try {
    // When Express mounts middleware at /main, it strips /main from req.path
    // So for request /main/main.css, req.path will be /main.css
    // req.originalUrl will still be /main/main.css
    
    let filePath = req.path;
    const originalUrl = req.originalUrl || req.url;
    
    // If req.path is empty or just '/', extract from originalUrl
    if (!filePath || filePath === '/' || filePath === '') {
      // Extract path after /main from originalUrl
      if (originalUrl.startsWith('/main/')) {
        filePath = originalUrl.substring(6); // Remove '/main/'
      } else if (originalUrl.startsWith('/main')) {
        filePath = originalUrl.substring(5); // Remove '/main'
        if (filePath.startsWith('/')) {
          filePath = filePath.substring(1); // Remove leading slash
        }
      } else {
        // Fallback: try to get from url
        filePath = originalUrl.replace(/^\/main/, '').replace(/^\//, '');
      }
    } else {
      // req.path already has the path (Express stripped /main)
      // Remove leading slash if present
      if (filePath.startsWith('/')) {
        filePath = filePath.substring(1);
      }
    }
    
    // Remove query string and hash
    filePath = filePath.split('?')[0].split('#')[0];
    
    // Decode URL encoding
    if (filePath.includes('%')) {
      try {
        filePath = decodeURIComponent(filePath);
      } catch (e) {
        console.error('URL decode error:', filePath, e.message);
      }
    }
    
    if (!filePath || filePath.trim() === '') {
      console.error('Empty file path for URL:', originalUrl);
      return res.status(404).send('File not found: empty path');
    }
    
    // Build full file path
    const fullPath = path.join(mainStaticPath, filePath);
    const normalizedPath = path.normalize(path.resolve(fullPath));
    
    // Security: ensure file is within allowed directory
    const allowedBase = path.normalize(path.resolve(mainStaticPath));
    if (!normalizedPath.startsWith(allowedBase + path.sep) && normalizedPath !== allowedBase) {
      console.error('Security violation:', normalizedPath, 'not in', allowedBase);
      return res.status(403).send('Forbidden');
    }
    
    // Check if file exists
    if (!fs.existsSync(normalizedPath)) {
      console.error('File not found:', {
        requestedPath: filePath,
        fullPath: normalizedPath,
        baseDir: mainStaticPath,
        originalUrl: originalUrl,
        reqPath: req.path,
        baseDirExists: fs.existsSync(mainStaticPath)
      });
      return res.status(404).send('File not found: ' + filePath);
    }
    
    const stats = fs.statSync(normalizedPath);
    if (!stats.isFile()) {
      console.error('Path is not a file:', normalizedPath);
      return res.status(404).send('Not a file');
    }
    
    // Set content type
    const ext = path.extname(normalizedPath).toLowerCase();
    const contentTypes = {
      '.css': 'text/css; charset=utf-8',
      '.js': 'application/javascript; charset=utf-8',
      '.svg': 'image/svg+xml; charset=utf-8',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.webp': 'image/webp',
      '.ico': 'image/x-icon'
    };
    const contentType = contentTypes[ext] || 'application/octet-stream';
    
    // Set headers
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Length', stats.size);
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.setHeader('Last-Modified', stats.mtime.toUTCString());
    
    // Send file
    return res.sendFile(normalizedPath, (err) => {
      if (err && !res.headersSent) {
        console.error('Error sending file:', err);
        res.status(500).send('Error reading file');
      }
    });
  } catch (err) {
    console.error('Error in serveMainFile:', err);
    console.error('Stack:', err.stack);
    if (!res.headersSent) {
      return res.status(500).send('Internal server error');
    }
  }
}

// Handle ALL /main requests - this MUST be before other static file routes
// Use app.use to catch all requests starting with /main
app.use('/main', (req, res, next) => {
  // Log request for debugging
  console.log('[/main] Request:', {
    method: req.method,
    originalUrl: req.originalUrl,
    url: req.url,
    path: req.path
  });
  
  // Only handle if it's a file request (has an extension or is not just /main)
  const url = req.originalUrl || req.url;
  
  // Skip if request is for /main only (without file path)
  if (url === '/main' || url === '/main/') {
    return next();
  }
  
  // Serve the file - this function handles the response
  serveMainFile(req, res);
});

app.use('/admin', decodeUrlMiddleware, express.static(path.join(__dirname, 'public', 'admin')));
app.use('/instruction', decodeUrlMiddleware, express.static(path.join(__dirname, 'public', 'instruction'), {
  setHeaders: (res, filePath) => {
    // Убеждаемся, что файлы с кириллицей правильно отдаются
    if (filePath.includes('Снимок')) {
      res.setHeader('Content-Disposition', 'inline');
    }
  }
}));
app.use('/privacy', decodeUrlMiddleware, express.static(path.join(__dirname, 'public', 'privacy')));

// Роуты страниц
app.get('/favicon.ico', (req, res) => {
  res.status(204).end();
});

app.get('/instruction', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'instruction', 'instruction.html'));
});

app.get('/privacy', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'privacy', 'privacy.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin', 'admin.html'));
});

// Главная страница
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Запуск сервера
const PORT = process.env.PORT || 8000;
server.listen(PORT, () => {
  console.log(`Server starting on :${PORT}...`);
  console.log('Database: PostgreSQL');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  await pool.end();
  server.close();
  process.exit(0);
});
