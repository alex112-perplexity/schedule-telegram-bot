<?php
// Минимальный прокси для статических файлов на reg.ru
$requestUri = $_SERVER['REQUEST_URI'];

// Убираем query string для чистого URI
$requestUri = strtok($requestUri, '?');

$nodeUrl = 'http://127.0.0.1:8000' . $requestUri;

$ch = curl_init($nodeUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    http_response_code(502);
    echo "Proxy error: " . $error;
    exit;
}

if ($httpCode == 200 && $response) {
    $headers = substr($response, 0, $headerSize);
    $body = substr($response, $headerSize);
    
    // Передаем заголовки
    $headerLines = explode("\r\n", $headers);
    foreach ($headerLines as $header) {
        if (stripos($header, 'Content-Type:') === 0 || 
            stripos($header, 'Content-Length:') === 0 ||
            stripos($header, 'Cache-Control:') === 0) {
            header($header);
        }
    }
    
    http_response_code(200);
    echo $body;
} else {
    http_response_code($httpCode ?: 404);
    if ($httpCode != 200) {
        echo "File not found: " . $requestUri;
    }
}

