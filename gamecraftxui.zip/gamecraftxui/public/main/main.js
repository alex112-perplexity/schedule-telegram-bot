// Бургер-меню
(function(){
  const burger = document.querySelector('.burger');
  const menu = document.getElementById('mobileMenu');
  if (!burger || !menu) return;
  const toggle = (open) => {
    const isOpen = open ?? !menu.classList.contains('open');
    menu.classList.toggle('open', isOpen);
    burger.setAttribute('aria-expanded', String(isOpen));
  };
  burger.addEventListener('click', () => toggle());
  
  // Закрываем меню при клике на любую ссылку в меню
  const menuLinks = menu.querySelectorAll('a');
  menuLinks.forEach(link => {
    link.addEventListener('click', () => {
      toggle(false);
    });
  });
  
  document.addEventListener('click', (e) => {
    if (!menu.classList.contains('open')) return;
    const within = menu.contains(e.target) || burger.contains(e.target);
    if (!within) toggle(false);
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') toggle(false); });
})();

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Карусель отзывов - загружаются из БД
const testimonials = [];

let carouselPosition = 0;
const cardWidth = 344; // 320px + 24px gap
let isTransitioning = false;

function renderTestimonials() {
  const carousel = document.getElementById('testimonialsCarousel');
  if (!carousel || testimonials.length === 0) return;
  
  // Дублируем отзывы для бесконечной прокрутки (3 копии)
  const duplicatedTestimonials = [...testimonials, ...testimonials, ...testimonials];
  
  carousel.innerHTML = duplicatedTestimonials.map((testimonial, index) => {
    const stars = '★'.repeat(testimonial.stars) + '☆'.repeat(5 - testimonial.stars);
    return `
      <div class="testimonial-card" data-index="${index % testimonials.length}">
        <div class="testimonial-name">${escapeHtml(testimonial.name)}</div>
        <div class="testimonial-stars">
          ${'★'.repeat(testimonial.stars).split('').map(() => '<span class="testimonial-star">★</span>').join('')}
          ${'☆'.repeat(5 - testimonial.stars).split('').map(() => '<span class="testimonial-star empty">☆</span>').join('')}
        </div>
        <div class="testimonial-text">"${escapeHtml(testimonial.text)}"</div>
      </div>
    `;
  }).join('');
  
  // Устанавливаем начальную позицию на вторую копию (середина)
  carouselPosition = testimonials.length;
  updateCarousel();
}

function updateCarousel() {
  const carousel = document.getElementById('testimonialsCarousel');
  if (!carousel) return;
  
  // Плавная анимация
  carousel.style.transition = isTransitioning ? 'transform 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94)' : 'none';
  carousel.style.transform = `translateX(-${carouselPosition * cardWidth}px)`;
  
  // Бесконечная прокрутка: если достигли конца, переходим на начало
  const totalCards = testimonials.length * 3;
  if (carouselPosition >= testimonials.length * 2) {
    setTimeout(() => {
      carousel.style.transition = 'none';
      carouselPosition = testimonials.length;
      carousel.style.transform = `translateX(-${carouselPosition * cardWidth}px)`;
    }, 600);
  } else if (carouselPosition < 0) {
    setTimeout(() => {
      carousel.style.transition = 'none';
      carouselPosition = testimonials.length;
      carousel.style.transform = `translateX(-${carouselPosition * cardWidth}px)`;
    }, 600);
  }
}

function moveCarousel(direction) {
  if (isTransitioning || testimonials.length === 0) return;
  
  const carousel = document.getElementById('testimonialsCarousel');
  if (!carousel) return;
  
  isTransitioning = true;
  carouselPosition += direction;
  updateCarousel();
  
  setTimeout(() => {
    isTransitioning = false;
  }, 600);
}

function showAddReviewForm() {
  document.getElementById('reviewModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeReviewModal() {
  document.getElementById('reviewModal').classList.remove('open');
  document.body.style.overflow = '';
  document.getElementById('reviewForm').reset();
  document.getElementById('reviewStars').value = '0';
  updateStarRating(0);
  document.getElementById('reviewStatusMessage').className = 'review-status-message';
  document.getElementById('reviewStatusMessage').textContent = '';
}

function setRating(rating) {
  document.getElementById('reviewStars').value = rating;
  updateStarRating(rating);
}

function updateStarRating(rating) {
  const stars = document.querySelectorAll('.star-rating-btn');
  stars.forEach((star, index) => {
    if (index < rating) {
      star.classList.add('active');
    } else {
      star.classList.remove('active');
    }
  });
}

async function submitReview(event) {
  event.preventDefault();
  
  if (isFileProtocol) {
    alert('Для отправки отзыва необходимо запустить сервер. Откройте сайт через http://localhost:8000');
    return;
  }
  
  const name = document.getElementById('reviewName').value.trim();
  const stars = parseInt(document.getElementById('reviewStars').value);
  const text = document.getElementById('reviewText').value.trim();
  const submitBtn = document.getElementById('reviewSubmitBtn');
  const statusMsg = document.getElementById('reviewStatusMessage');
  
  if (!stars || stars < 1 || stars > 5) {
    statusMsg.className = 'review-status-message error';
    statusMsg.textContent = 'Пожалуйста, выберите оценку от 1 до 5 звезд';
    return;
  }
  
  submitBtn.disabled = true;
  submitBtn.textContent = 'Отправка...';
  
  try {
    const response = await fetch('/api/reviews', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: name,
        stars: stars,
        text: text,
        status: 'pending'
      }),
    });
    
    if (response.ok) {
      statusMsg.className = 'review-status-message success';
      statusMsg.textContent = 'Спасибо! Ваш отзыв отправлен на модерацию. После проверки он появится на сайте.';
      document.getElementById('reviewForm').reset();
      document.getElementById('reviewStars').value = '0';
      updateStarRating(0);
      
      setTimeout(() => {
        closeReviewModal();
      }, 2000);
    } else {
      throw new Error('Ошибка отправки отзыва');
    }
  } catch (error) {
    statusMsg.className = 'review-status-message error';
    statusMsg.textContent = 'Произошла ошибка. Попробуйте позже.';
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Отправить на модерацию';
  }
}

// Закрытие модального окна при клике вне его
document.getElementById('reviewModal')?.addEventListener('click', (e) => {
  if (e.target.id === 'reviewModal') {
    closeReviewModal();
  }
});

// Закрытие по Escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && document.getElementById('reviewModal')?.classList.contains('open')) {
    closeReviewModal();
  }
});

// Проверка протокола - отключаем API запросы для file://
const isFileProtocol = window.location.protocol === 'file:';
const API_BASE = isFileProtocol ? '' : '';

// Загрузка отзывов с сервера (только из БД)
async function loadReviews() {
  if (isFileProtocol) {
    // Для file:// показываем сообщение
    const carousel = document.getElementById('testimonialsCarousel');
    if (carousel) {
      carousel.innerHTML = '<div class="testimonial-card"><div class="testimonial-text">Для просмотра отзывов откройте сайт через http://localhost:8000</div></div>';
    }
    return;
  }
  
  try {
    const response = await fetch('/api/reviews?status=approved');
    if (response.ok) {
      const approvedReviews = await response.json();
      if (Array.isArray(approvedReviews) && approvedReviews.length > 0) {
        // Очищаем массив и загружаем отзывы из БД
        testimonials.length = 0;
        approvedReviews.forEach(review => {
          testimonials.push({
            id: review.id,
            name: review.name,
            stars: review.stars,
            text: review.text
          });
        });
        renderTestimonials();
      } else {
        // Если нет отзывов, показываем сообщение
        const carousel = document.getElementById('testimonialsCarousel');
        if (carousel) {
          carousel.innerHTML = '<div class="testimonial-card"><div class="testimonial-text">Пока нет отзывов. Будьте первым!</div></div>';
        }
      }
    }
  } catch (error) {
    console.error('Error loading reviews:', error);
    const carousel = document.getElementById('testimonialsCarousel');
    if (carousel) {
      carousel.innerHTML = '<div class="testimonial-card"><div class="testimonial-text" style="color:#ff8346;">Ошибка загрузки отзывов</div></div>';
    }
  }
}

let autoScrollInterval = null;
let isPageVisible = true;

// Останавливаем автопрокрутку когда страница не видна
document.addEventListener('visibilitychange', () => {
  isPageVisible = !document.hidden;
  if (isPageVisible && !autoScrollInterval) {
    autoScrollInterval = setInterval(autoScrollCarousel, 5000);
  } else if (!isPageVisible && autoScrollInterval) {
    clearInterval(autoScrollInterval);
    autoScrollInterval = null;
  }
});

// Поддержка свайпа на мобильных устройствах
let touchStartX = 0;
let touchEndX = 0;

function handleSwipe() {
  const carousel = document.getElementById('testimonialsCarousel');
  if (!carousel) return;
  
  carousel.addEventListener('touchstart', (e) => {
    touchStartX = e.changedTouches[0].screenX;
  });
  
  carousel.addEventListener('touchend', (e) => {
    touchEndX = e.changedTouches[0].screenX;
    handleSwipeGesture();
  });
}

function handleSwipeGesture() {
  const swipeThreshold = 50;
  const diff = touchStartX - touchEndX;
  
  if (Math.abs(diff) > swipeThreshold) {
    if (diff > 0) {
      moveCarousel(1); // Свайп влево - вперед
    } else {
      moveCarousel(-1); // Свайп вправо - назад
    }
  }
}

// Автопрокрутка карусели (бесконечная)
function autoScrollCarousel() {
  if (!isPageVisible || testimonials.length === 0 || isTransitioning) return;
  
  const carousel = document.getElementById('testimonialsCarousel');
  if (!carousel) return;
  
  isTransitioning = true;
  carouselPosition += 1;
  updateCarousel();
  
  setTimeout(() => {
    isTransitioning = false;
  }, 600);
}

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', () => {
  loadReviews();
  handleSwipe();
  // Автопрокрутка каждые 5 секунд только если страница видна
  if (isPageVisible) {
    autoScrollInterval = setInterval(autoScrollCarousel, 5000);
  }
});

// Копирование кода курса
function copyCourseCode(code, btn) {
  navigator.clipboard.writeText(code);
  const originalText = btn.textContent;
  btn.textContent = '✓ КОД СКОПИРОВАН';
  btn.style.background = 'linear-gradient(135deg, rgba(107,107,107,0.85), rgba(74,74,74,0.95))';
  setTimeout(function() {
    btn.textContent = originalText;
    btn.style.background = '';
  }, 3000);
}

// FAQ аккордеон
(function(){
  document.querySelectorAll('.faq-item').forEach((item) => {
    const q = item.querySelector('.faq-question');
    const a = item.querySelector('.faq-answer');
    if (!q || !a) return;
    const toggle = () => {
      const open = !item.classList.contains('open');
      item.classList.toggle('open', open);
      item.setAttribute('aria-expanded', String(open));
      q.setAttribute('aria-expanded', String(open));
      a.setAttribute('aria-hidden', String(!open));
    };
    item.addEventListener('click', (e) => { e.preventDefault(); toggle(); });
    item.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
  });
})();

// Валидация формы и индикатор отправки
(function(){
  const form = document.getElementById('registerForm');
  if (!form) return;
  const status = document.getElementById('formStatus');
  const submitBtn = document.getElementById('submitBtn');
  const setError = (input, msg) => {
    const group = input.closest('.form-group');
    const err = group ? group.querySelector('.error-text') : null;
    if (err) { err.style.display = msg ? 'block' : 'none'; if (msg) err.textContent = msg; }
    input.style.borderColor = msg ? '#ff6b4a' : 'rgba(255,255,255,0.3)';
  };
  const clearErrors = () => form.querySelectorAll('.error-text').forEach(e => e.style.display = 'none');
  const validate = () => {
    let ok = true;
    const fio = form.elements['fio'];
    const group = form.elements['group'];
    const age = form.elements['age'];
    const college = form.elements['college'];
    const position = form.elements['position'];
    const privacy = form.elements['privacy'];
    if (!fio.value.trim()) { setError(fio, 'Пожалуйста, укажите ФИО'); ok = false; } else setError(fio, '');
    if (!group.value.trim()) { setError(group, 'Укажите группу'); ok = false; } else setError(group, '');
    const ageVal = Number(age.value);
    if (!age.value || ageVal < 14 || ageVal > 99) { setError(age, 'Возраст от 14 до 99'); ok = false; } else setError(age, '');
    if (!college.value.trim()) { setError(college, 'Укажите колледж'); ok = false; } else setError(college, '');
    if (!position.value) { setError(position, 'Выберите позицию'); ok = false; } else setError(position, '');
    if (!privacy.checked) { status.style.display='block'; status.style.color='#ff9a5a'; status.textContent='Подтвердите согласие с политикой'; ok = false; }
    return ok;
  };
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors();
    status.style.display='none';
    if (!validate()) return;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Отправка...';
    status.style.display='block'; status.style.color='#b8b8c0'; status.textContent='Отправляем заявку...';
    await new Promise(r => setTimeout(r, 800));
    
    // Сохраняем заявку
    const application = {
      fio: form.elements['fio'].value.trim(),
      group: form.elements['group'].value.trim(),
      age: parseInt(form.elements['age'].value),
      college: form.elements['college'].value.trim(),
      position: form.elements['position'].value,
      date: new Date().toISOString()
    };
    
    // Отправляем на сервер
    try {
      if (isFileProtocol) {
        status.style.color = '#ff9a5a';
        status.textContent = 'Для отправки заявки необходимо запустить сервер. Откройте сайт через http://localhost:8000';
        submitBtn.textContent = 'Ошибка';
        return;
      }
      
      const response = await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(application)
      });
      
      if (response.ok) {
        status.style.color = '#6aff9f';
        status.textContent = 'Спасибо! Заявка отправлена. Мы свяжемся с вами.';
        submitBtn.textContent = 'Отправлено';
        form.reset();
      } else {
        throw new Error('Ошибка отправки');
      }
    } catch (error) {
      status.style.color = '#ff9a5a';
      status.textContent = 'Ошибка отправки. Попробуйте позже.';
      submitBtn.textContent = 'Ошибка';
    }
  });
  form.querySelectorAll('input, select').forEach((el) => {
    el.addEventListener('input', () => {
      const group = el.closest('.form-group');
      const err = group ? group.querySelector('.error-text') : null;
      if (err) err.style.display = 'none';
      el.style.borderColor = 'rgba(255,255,255,0.3)';
    });
  });
})();

let chatOpen = false;
let ws = null;

// Генерация уникального ID пользователя
function getUserId() {
  let userId = localStorage.getItem('gamecraft_user_id');
  if (!userId) {
    // Генерируем уникальный ID
    userId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('gamecraft_user_id', userId);
  }
  return userId;
}

const currentUserId = getUserId();

function toggleChat() {
  const chatWindow = document.getElementById('chatWindow');
  chatOpen = !chatOpen;
  chatWindow.classList.toggle('active', chatOpen);
  
  if (chatOpen) {
    document.getElementById('chatBadge').style.display = 'none';
  }
  
  if (chatOpen && document.getElementById('chatMessages').querySelectorAll('.chat-message').length === 1) {
    loadChatMessages();
  }
}

function handleChatKeyPress(event) {
  if (event.key === 'Enter') {
    sendMessage();
  }
}

function getBotResponse(message) {
  const lowerMsg = message.toLowerCase();
  
  if (lowerMsg.includes('регистрация') || lowerMsg.includes('запись')) {
    return 'Для регистрации на марафон заполните форму на странице. Все вопросы? Пишите!';
  } else if (lowerMsg.includes('расписание') || lowerMsg.includes('когда')) {
    return 'Марафон проходит с ноября по май. Точное расписание занятий уточняйте у организаторов.';
  } else if (lowerMsg.includes('опыт') || lowerMsg.includes('новичок')) {
    return 'Марафон подходит и для новичков, и для опытных! Для новичков есть онлайн-платформа с уроками.';
  } else if (lowerMsg.includes('привет') || lowerMsg.includes('здравствуйте')) {
    return 'Здравствуйте! Я виртуальный помощник марафона GameCraft. Чем могу помочь?';
  } else if (lowerMsg.includes('спасибо') || lowerMsg.includes('благодарю')) {
    return 'Пожалуйста! Удачи на марафоне! 🎮';
  } else {
    return 'Спасибо за вопрос! Админ скоро ответит на ваш вопрос.';
  }
}

function addMessageToChat(msg) {
  const messagesDiv = document.getElementById('chatMessages');
  const messageDiv = document.createElement('div');
  messageDiv.className = msg.type === 'user' ? 'chat-message chat-user' : 'chat-message chat-admin';
  
  if (msg.type === 'user') {
    messageDiv.innerHTML = `<div class="chat-avatar" style="background: linear-gradient(135deg, rgba(255,131,70,0.8), rgba(253,52,81,0.8)); font-size: 28px;">👤</div><div class="chat-content"><div class="chat-bubble">${escapeHtml(msg.text)}</div></div>`;
  } else {
    messageDiv.innerHTML = `<div class="chat-avatar" style="${msg.type === 'admin' ? 'background: linear-gradient(135deg, #4a9eff, #2a5fd6);' : ''} font-size: 28px;">${msg.type === 'admin' ? '👨‍💼' : '🤖'}</div><div class="chat-content"><div class="chat-bubble">${escapeHtml(msg.text)}</div></div>`;
  }
  
  messagesDiv.appendChild(messageDiv);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function loadChatMessages() {
  if (isFileProtocol) {
    // Для file:// показываем только начальное сообщение
    const messagesDiv = document.getElementById('chatMessages');
    messagesDiv.innerHTML = '<div class="chat-message chat-bot"><div class="chat-avatar">🤖</div><div class="chat-content"><div class="chat-bubble">Здравствуйте! Чем могу помочь?</div></div></div>';
    return;
  }
  // Загружаем только сообщения текущего пользователя
  fetch(`/api/chat?user_id=${currentUserId}`)
    .then(res => res.json())
    .then(messages => {
      const messagesDiv = document.getElementById('chatMessages');
      messagesDiv.innerHTML = '<div class="chat-message chat-bot"><div class="chat-avatar" style="font-size: 28px;">🤖</div><div class="chat-content"><div class="chat-bubble">Здравствуйте! Чем могу помочь?</div></div></div>';
      messages.forEach(msg => addMessageToChat(msg));
    })
    .catch(err => console.error('Error loading chat:', err));
}

function sendMessage() {
  const input = document.getElementById('chatInput');
  const message = input.value.trim();
  if (!message) return;
  
  if (isFileProtocol) {
    alert('Для отправки сообщения необходимо запустить сервер. Откройте сайт через http://localhost:8000');
    input.value = '';
    return;
  }
  
  // Если WebSocket доступен, используем его
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ text: message, type: 'user', user_id: currentUserId }));
  } else {
    // Fallback: отправляем через HTTP
    fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: message, type: 'user', user_id: currentUserId })
    }).then(() => {
      // Обновляем сообщения после отправки
      setTimeout(loadChatMessages, 500);
    });
  }
  input.value = '';
  
  setTimeout(() => {
    const botResponse = getBotResponse(message);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ text: botResponse, type: 'bot', user_id: currentUserId }));
    } else {
      // Fallback: отправляем бота через HTTP
      fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: botResponse, type: 'bot', user_id: currentUserId })
      }).then(() => {
        setTimeout(loadChatMessages, 500);
      });
    }
  }, 1000);
}

function connectWebSocket() {
  if (isFileProtocol) {
    // Для file:// протокола не подключаемся к WebSocket
    return;
  }
  
  if (!window.location.host) {
    // Если нет хоста (file://), не подключаемся
    return;
  }
  
  // WebSocket не работает через PHP прокси на REG.RU
  // Сразу используем HTTP polling
  console.log('Используется HTTP polling для чата');
  loadChatMessages();
  if (!window.chatPollInterval) {
    window.chatPollInterval = setInterval(loadChatMessages, 5000);
  }
  return;
  
  // Код ниже не выполняется, но оставлен для будущего использования
  /*
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = protocol + '//' + window.location.host + '/api/chat/ws';
  
  try {
    ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      // Отправляем user_id при подключении
      ws.send(JSON.stringify({ type: 'set_user_id', user_id: currentUserId }));
    };
    
    ws.onmessage = (event) => {
      const update = JSON.parse(event.data);
      if (update.type === 'new_message') {
        if (update.message && (update.message.user_id === currentUserId || update.message.type === 'admin' || update.message.type === 'bot')) {
          addMessageToChat(update.message);
        }
      } else if (update.type === 'history') {
        if (update.message && (update.message.user_id === currentUserId || update.message.type === 'admin' || update.message.type === 'bot')) {
          addMessageToChat(update.message);
        }
      }
    };
    
    ws.onerror = (error) => {
      ws = null;
      loadChatMessages();
      if (!window.chatPollInterval) {
        window.chatPollInterval = setInterval(loadChatMessages, 5000);
      }
    };
    
    ws.onclose = () => {
      if (ws && ws.readyState === WebSocket.CLOSED) {
        ws = null;
        if (!window.chatPollInterval) {
          window.chatPollInterval = setInterval(loadChatMessages, 5000);
        }
      }
    };
  } catch (error) {
    // Игнорируем ошибки
  }
  */
}

// Используем HTTP polling вместо WebSocket (WebSocket не работает через PHP прокси)
if (!isFileProtocol && window.location.host) {
  connectWebSocket(); // Функция теперь сразу использует HTTP polling
}
