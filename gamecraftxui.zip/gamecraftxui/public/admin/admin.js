let searchTimeout = null;
let selectedUserId = null;
let userReadTimes = {}; // Храним время последнего чтения чата каждого пользователя

function debounceSearch(func, delay) {
  return function(...args) {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => func.apply(this, args), delay);
  };
}

const debouncedLoadApplications = debounceSearch(loadApplications, 300);

function switchTab(tabName, tabElement) {
  // Убираем активный класс со всех табов и секций
  document.querySelectorAll('.admin-tab').forEach(tab => tab.classList.remove('active'));
  document.querySelectorAll('.admin-section').forEach(section => section.classList.remove('active'));
  
  // Активируем выбранный таб
  tabElement.classList.add('active');
  
  // Показываем соответствующую секцию
  const sections = {
    'applications': 'applicationsSection',
    'chat': 'chatSection',
    'reviews': 'reviewsSection'
  };
  
  document.getElementById(sections[tabName]).classList.add('active');
  
  // Обновляем данные при переключении таба
  if (tabName === 'applications') {
    loadApplications();
  } else if (tabName === 'chat') {
    loadChat();
  } else if (tabName === 'reviews') {
    loadReviews();
  }
}

function loadApplications() {
  fetch('/api/applications')
    .then(res => res.json())
    .then(apps => {
      const appsList = document.getElementById('appsList');
      const searchInput = document.getElementById('searchInput');
      const filterSelect = document.getElementById('filterSelect');
      
      // Проверяем, что apps не null
      if (!apps || !Array.isArray(apps)) {
        apps = [];
      }
      
      // Фильтруем заявки
      let filteredApps = apps;
      
      // Поиск
      if (searchInput && searchInput.value.trim()) {
        const searchTerm = searchInput.value.toLowerCase().trim();
        filteredApps = filteredApps.filter(app => 
          app.fio.toLowerCase().includes(searchTerm) ||
          app.group.toLowerCase().includes(searchTerm) ||
          app.college.toLowerCase().includes(searchTerm)
        );
      }
      
      // Фильтр по позиции
      if (filterSelect && filterSelect.value) {
        filteredApps = filteredApps.filter(app => app.position === filterSelect.value);
      }
      
      if (filteredApps.length === 0) {
        appsList.innerHTML = '<div class="empty-state">Нет заявок</div>';
        return;
      }
      
      // Сортируем по дате (новые первыми)
      filteredApps.sort((a, b) => new Date(b.date) - new Date(a.date));
      
      appsList.innerHTML = filteredApps.map((app, index) => `
        <div class="app-item">
          <div class="app-item-header">
            <div class="app-name">${app.fio}</div>
            <div class="app-date">${new Date(app.date).toLocaleString('ru-RU')}</div>
          </div>
          <div class="app-details">
            <div class="app-field">
              <div class="app-label">Группа:</div>
              <div class="app-value">${app.group}</div>
            </div>
            <div class="app-field">
              <div class="app-label">Возраст:</div>
              <div class="app-value">${app.age}</div>
            </div>
            <div class="app-field">
              <div class="app-label">Колледж:</div>
              <div class="app-value">${app.college}</div>
            </div>
            <div class="app-field">
              <div class="app-label">Позиция:</div>
              <div class="app-value">${app.position}</div>
            </div>
          </div>
        </div>
      `).join('');
    })
    .catch(err => {
      console.error('Error loading applications:', err);
      document.getElementById('appsList').innerHTML = '<div class="empty-state">Ошибка загрузки</div>';
    });
}

function exportApplications() {
  fetch('/api/applications')
    .then(res => res.json())
    .then(apps => {
      if (apps.length === 0) {
        alert('Нет заявок для экспорта');
        return;
      }
      
      // Создаем CSV
      const headers = ['ФИО', 'Группа', 'Возраст', 'Колледж', 'Позиция', 'Дата регистрации'];
      const rows = apps.map(app => [
        app.fio,
        app.group,
        app.age,
        app.college,
        app.position,
        new Date(app.date).toLocaleString('ru-RU')
      ]);
      
      const csvContent = [
        headers.join(','),
        ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
      ].join('\n');
      
      // Скачиваем файл
      const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `gamecraft_applications_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    })
    .catch(err => console.error('Error exporting:', err));
}

function clearAll() {
  if (confirm('Вы уверены, что хотите удалить все заявки?')) {
    fetch('/api/applications', { method: 'DELETE' })
      .then(() => loadApplications())
      .catch(err => console.error('Error clearing:', err));
  }
}

function loadChat() {
  const usersList = document.getElementById('usersList');
  const chatList = document.getElementById('chatList');
  
  // Показываем индикатор загрузки
  usersList.innerHTML = '<div style="text-align:center; padding:20px; color:#999;">Загрузка...</div>';
  chatList.innerHTML = '<div style="text-align:center; padding:20px; color:#999;">Выберите пользователя</div>';
  
  fetch('/api/chat')
    .then(res => {
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      return res.json();
    })
    .then(messages => {
      // Проверяем, что messages не null
      if (!messages || !Array.isArray(messages)) {
        messages = [];
      }
      
      // Группируем сообщения по user_id
      const messagesByUser = {};
      messages.forEach(msg => {
        const userId = msg.user_id || 'unknown';
        if (!messagesByUser[userId]) {
          messagesByUser[userId] = [];
        }
        messagesByUser[userId].push(msg);
      });
      
      // Удаляем 'unknown' пользователей
      delete messagesByUser['unknown'];
      
      // Сортируем пользователей: сначала с новыми сообщениями
      const userList = Object.keys(messagesByUser).map(userId => {
        const userMessages = messagesByUser[userId];
        const lastMessage = userMessages[userMessages.length - 1];
        const lastReadTime = userReadTimes[userId] || 0;
        const unreadCount = userMessages.filter(m => 
          m.type === 'user' && new Date(m.date).getTime() > lastReadTime
        ).length;
        
        return {
          userId,
          messages: userMessages,
          lastMessage,
          unreadCount,
          lastMessageTime: new Date(lastMessage.date).getTime()
        };
      });
      
      // Сортируем: сначала с непрочитанными, потом по времени последнего сообщения
      userList.sort((a, b) => {
        if (a.unreadCount > 0 && b.unreadCount === 0) return -1;
        if (a.unreadCount === 0 && b.unreadCount > 0) return 1;
        return b.lastMessageTime - a.lastMessageTime;
      });
      
      // Обновляем общий счетчик непрочитанных
      const totalUnread = userList.reduce((sum, user) => sum + user.unreadCount, 0);
      const unreadCount = document.getElementById('unreadCount');
      unreadCount.textContent = totalUnread > 0 ? `${totalUnread} новых` : 'Нет новых';
      
      // Отображаем карточки пользователей
      if (userList.length === 0) {
        usersList.innerHTML = '<div class="empty-state">Нет пользователей</div>';
        chatList.innerHTML = '<div class="empty-state">Нет сообщений</div>';
        return;
      }
      
      usersList.innerHTML = userList.map(user => {
        const lastMsg = user.lastMessage;
        const lastMsgText = escapeHtml(lastMsg.text);
        const lastMsgTime = new Date(lastMsg.date).toLocaleString('ru-RU', {
          day: '2-digit',
          month: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        });
        
        return `
          <div class="user-card ${user.unreadCount > 0 ? 'has-new' : ''} ${selectedUserId === user.userId ? 'selected' : ''}" 
               onclick="selectUser('${user.userId}')">
            <div class="user-card-header">
              <div class="user-card-id">${user.userId.substring(0, 25)}...</div>
              ${user.unreadCount > 0 ? `<div class="user-card-badge">${user.unreadCount}</div>` : ''}
            </div>
            <div class="user-card-last-message">${lastMsgText.substring(0, 40)}${lastMsgText.length > 40 ? '...' : ''}</div>
            <div class="user-card-time">${lastMsgTime}</div>
          </div>
        `;
      }).join('');
      
      // Отображаем чат выбранного пользователя
      if (selectedUserId && messagesByUser[selectedUserId]) {
        displayUserChat(selectedUserId, messagesByUser[selectedUserId]);
      } else {
        chatList.innerHTML = '<div class="empty-state">Выберите пользователя для просмотра чата</div>';
      }
    })
    .catch(err => {
      console.error('Error loading chat:', err);
      usersList.innerHTML = '<div class="empty-state" style="color:#ff8346;">Ошибка загрузки</div>';
      chatList.innerHTML = '<div class="empty-state" style="color:#ff8346;">Ошибка загрузки сообщений</div>';
    });
}

function selectUser(userId) {
  selectedUserId = userId;
  // Обновляем время прочтения
  userReadTimes[userId] = Date.now();
  
  // Перезагружаем чат для обновления карточек
  loadChat();
}

function displayUserChat(userId, messages) {
  const chatList = document.getElementById('chatList');
  
  // Сортируем сообщения по времени
  messages.sort((a, b) => new Date(a.date) - new Date(b.date));
  
  let html = `<div style="padding:10px; background:rgba(255,131,70,0.2); border-radius:8px; margin-bottom:15px; font-weight:700; color:#ff8346;">Пользователь: ${userId.substring(0, 30)}...</div>`;
  
  html += messages.map(msg => {
    const isUser = msg.type === 'user';
    const iconSize = '48px';
    const iconStyle = `width:${iconSize}; height:${iconSize}; border-radius:50%; background:${isUser ? 'linear-gradient(135deg, rgba(255,131,70,0.8), rgba(253,52,81,0.8))' : msg.type === 'admin' ? 'linear-gradient(135deg, #4a9eff, #2a5fd6)' : 'linear-gradient(135deg, #ff8346, #fd3451)'}; display:flex; align-items:center; justify-content:center; font-size:32px; flex-shrink:0; box-shadow:0 2px 8px rgba(0,0,0,0.2);`;
    return `<div class="chat-item" style="display:flex; gap:15px; margin-bottom:15px; ${isUser ? 'flex-direction:row-reverse;' : ''}"><div style="${iconStyle}">${msg.type === 'admin' ? '👨‍💼' : msg.type === 'bot' ? '🤖' : '👤'}</div><div style="flex:1;"><div style="background:rgba(32,32,60,0.4); border-radius:12px; padding:12px 16px; margin-bottom:5px; ${isUser ? 'background:rgba(255,131,70,0.2);' : msg.type === 'admin' ? 'background:rgba(74,158,255,0.2);' : ''}"><div style="color:#fff; font-size:14px; white-space:pre-wrap;">${escapeHtml(msg.text)}</div></div><div style="color:#999; font-size:12px; text-align:${isUser ? 'right' : 'left'};">${new Date(msg.date).toLocaleString('ru-RU')}</div></div></div>`;
  }).join('');
  
  chatList.innerHTML = html;
  
  // Автоскролл к последнему сообщению
  chatList.scrollTop = chatList.scrollHeight;
}

function sendAdminReply() {
  const input = document.getElementById('chatInput');
  const message = input.value.trim();
  
  if (!selectedUserId) {
    alert('Пожалуйста, выберите пользователя для ответа');
    return;
  }
  
  if (!message) return;
  
  // Блокируем поле ввода
  input.disabled = true;
  const button = input.nextElementSibling;
  if (button) button.disabled = true;
  
  // Отправляем через API с указанием user_id получателя
  fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: message, type: 'admin', user_id: selectedUserId })
  })
    .then(res => {
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      return res.json();
    })
    .then(() => {
      input.value = '';
      input.disabled = false;
      if (button) button.disabled = false;
      // Перезагружаем чат через API
      loadChat();
      input.focus();
    })
    .catch(err => {
      console.error('Error sending reply:', err);
      alert('Ошибка отправки сообщения через API. Попробуйте еще раз.');
      input.disabled = false;
      if (button) button.disabled = false;
    });
}

function handleChatKeyPress(event) {
  if (event.key === 'Enter') {
    sendAdminReply();
  }
}

function clearChat() {
  if (confirm('Вы уверены, что хотите очистить весь чат?')) {
    fetch('/api/chat', { method: 'DELETE' })
      .then(() => loadChat())
      .catch(err => console.error('Error clearing chat:', err));
  }
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function loadReviews() {
    fetch('/api/reviews?status=pending')
    .then(res => {
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      return res.json();
    })
    .then(data => {
      const reviewsList = document.getElementById('reviewsList');
      const pendingCount = document.getElementById('pendingReviewsCount');
      
      if (!Array.isArray(data) || data.length === 0) {
        reviewsList.innerHTML = '<div class="empty-state">Нет отзывов на модерацию</div>';
        pendingCount.textContent = '0';
        return;
      }
      
      pendingCount.textContent = data.length.toString();
      
      reviewsList.innerHTML = data.map(review => `
        <div class="review-item">
          <div class="review-header">
            <div>
              <div class="review-name">${escapeHtml(review.name)}</div>
              <div class="review-stars">${'★'.repeat(review.stars)}${'☆'.repeat(5 - review.stars)}</div>
            </div>
          </div>
          <div class="review-text">${escapeHtml(review.text)}</div>
          <div class="review-date">${new Date(review.date).toLocaleString('ru-RU')}</div>
          <div class="review-actions">
            <button class="btn-approve" onclick="approveReview(${review.id})">✓ Одобрить</button>
            <button class="btn-reject" onclick="rejectReview(${review.id})">✗ Отклонить</button>
          </div>
        </div>
      `).join('');
    })
    .catch(err => {
      console.error('Error loading reviews:', err);
      document.getElementById('reviewsList').innerHTML = '<div class="empty-state">Ошибка загрузки отзывов</div>';
    });
}

function approveReview(id) {
  fetch(`/api/reviews/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ status: 'approved' }),
  })
    .then(() => {
      loadReviews();
    })
    .catch(err => {
      console.error('Error approving review:', err);
      alert('Ошибка при одобрении отзыва');
    });
}

function rejectReview(id) {
  if (confirm('Вы уверены, что хотите отклонить этот отзыв?')) {
    fetch(`/api/reviews/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ status: 'rejected' }),
    })
      .then(() => {
        loadReviews();
      })
      .catch(err => {
        console.error('Error rejecting review:', err);
        alert('Ошибка при отклонении отзыва');
      });
  }
}

// Обновление данных только при действиях (без автообновления для чата)
// Для заявок и отзывов можно добавить автообновление, но чат обновляется только через API при действиях

// Загружаем при загрузке страницы
loadApplications();
loadChat();
loadReviews();

// Автообновление только для заявок и отзывов (каждые 5 секунд)
let pollingInterval = null;

function startPolling() {
  // Останавливаем предыдущий интервал, если есть
  if (pollingInterval) {
    clearInterval(pollingInterval);
  }
  
  // Обновляем только заявки и отзывы (не чат!)
  pollingInterval = setInterval(() => {
    const activeTab = document.querySelector('.admin-tab.active');
    if (activeTab) {
      const tabName = activeTab.textContent.trim();
      if (tabName === 'Заявки') {
        loadApplications();
      } else if (tabName === 'Модерация отзывов') {
        loadReviews();
      }
      // Чат НЕ обновляем автоматически - только через API при действиях
    }
  }, 5000);
}

startPolling();
